<?php
/*
Plugin Name: Divisas y Combustibles RD Version 1.1
Description: Muestra divisas y precios de combustibles con títulos editables e iconos modernos.
Version: 1.1
Author: MCV Studio
*/

if (!defined('ABSPATH')) exit;

// REGISTER SETTINGS
function dcrd_registrar_ajustes() {
    add_option('dcrd_titulo_divisas', 'Divisas');
    add_option('dcrd_titulo_combustibles', 'Combustibles');
    register_setting('dcrd_ajustes', 'dcrd_titulo_divisas');
    register_setting('dcrd_ajustes', 'dcrd_titulo_combustibles');

    $campos = [
        'dcrd_usd_compra','dcrd_usd_venta','dcrd_eur_compra','dcrd_eur_venta',
        'dcrd_gasolina_premium','dcrd_gasolina_regular','dcrd_gasoil_regular',
        'dcrd_gasoil_optimo','dcrd_glp','dcrd_gas_natural'
    ];
    foreach ($campos as $campo) { add_option($campo, ''); register_setting('dcrd_ajustes', $campo); }
}
add_action('admin_init', 'dcrd_registrar_ajustes');

// MENU
function dcrd_menu() {
    add_options_page('Divisas y Combustibles RD Version 1.1','Divisas y Combustibles RD','manage_options','divisas-combustibles-rd','dcrd_pagina_config');
}
add_action('admin_menu','dcrd_menu');

// SETTINGS PAGE
function dcrd_pagina_config() { ?>
<div class="wrap"><h1>Configuración - Divisas y Combustibles RD v1.1</h1>
<form method="post" action="options.php"><?php settings_fields('dcrd_ajustes'); ?>
<h2>Títulos</h2><table class="form-table">
<tr><th>Título Divisas</th><td><input type="text" name="dcrd_titulo_divisas" value="<?php echo get_option('dcrd_titulo_divisas'); ?>" style="width:300px;"></td></tr>
<tr><th>Título Combustibles</th><td><input type="text" name="dcrd_titulo_combustibles" value="<?php echo get_option('dcrd_titulo_combustibles'); ?>" style="width:300px;"></td></tr>
</table>

<h2>Divisas</h2><table class="form-table">
<tr><th>Dólar Compra</th><td><input type="text" name="dcrd_usd_compra" value="<?php echo get_option('dcrd_usd_compra'); ?>"></td></tr>
<tr><th>Dólar Venta</th><td><input type="text" name="dcrd_usd_venta" value="<?php echo get_option('dcrd_usd_venta'); ?>"></td></tr>
<tr><th>Euro Compra</th><td><input type="text" name="dcrd_eur_compra" value="<?php echo get_option('dcrd_eur_compra'); ?>"></td></tr>
<tr><th>Euro Venta</th><td><input type="text" name="dcrd_eur_venta" value="<?php echo get_option('dcrd_eur_venta'); ?>"></td></tr>
</table>

<h2>Combustibles</h2><table class="form-table">
<tr><th>Gasolina Premium</th><td><input type="text" name="dcrd_gasolina_premium" value="<?php echo get_option('dcrd_gasolina_premium'); ?>"></td></tr>
<tr><th>Gasolina Regular</th><td><input type="text" name="dcrd_gasolina_regular" value="<?php echo get_option('dcrd_gasolina_regular'); ?>"></td></tr>
<tr><th>Gasoil Regular</th><td><input type="text" name="dcrd_gasoil_regular" value="<?php echo get_option('dcrd_gasoil_regular'); ?>"></td></tr>
<tr><th>Gasoil Óptimo</th><td><input type="text" name="dcrd_gasoil_optimo" value="<?php echo get_option('dcrd_gasoil_optimo'); ?>"></td></tr>
<tr><th>GLP</th><td><input type="text" name="dcrd_glp" value="<?php echo get_option('dcrd_glp'); ?>"></td></tr>
<tr><th>Gas Natural</th><td><input type="text" name="dcrd_gas_natural" value="<?php echo get_option('dcrd_gas_natural'); ?>"></td></tr>
</table>

<input type="submit" class="button button-primary" value="Guardar Cambios"></form></div><?php }

// SHORTCODE
function dcrd_shortcode() {
    $titulo_divisas = get_option('dcrd_titulo_divisas','Divisas');
    $titulo_combustibles = get_option('dcrd_titulo_combustibles','Combustibles');
    ob_start(); ?>
<style>
.dcrd-card{
    max-width:340px;
    background:#f9f9f9;
    border-radius:16px;
    padding:16px;
    font-family:'Roboto',sans-serif;
    box-shadow:0 5px 20px rgba(0,0,0,.1);
    margin:10px auto;
}

.dcrd-card h3{
    text-align:center;
    font-size:18px;
    font-weight:600;
    margin-bottom:16px;
    padding:8px 12px;
    border:2px solid #c2c2c2; /* borde gris oscuro */
    border-radius:12px;
    background:#ffffff;
}
</style>

<div class="dcrd-card">
<h3><?php echo esc_html($titulo_divisas); ?></h3>
<table>
<tr><td>Dólar Compra</td><td class="valor">RD$ <?php echo get_option('dcrd_usd_compra'); ?></td></tr>
<tr><td>Dólar Venta</td><td class="valor">RD$ <?php echo get_option('dcrd_usd_venta'); ?></td></tr>
<tr><td>Euro Compra</td><td class="valor">RD$ <?php echo get_option('dcrd_eur_compra'); ?></td></tr>
<tr><td>Euro Venta</td><td class="valor">RD$ <?php echo get_option('dcrd_eur_venta'); ?></td></tr>
</table>

<h3 style="margin-top:24px;"><?php echo esc_html($titulo_combustibles); ?></h3>
<table>
<?php
$combustibles=[
'Gasolina Premium'=>get_option('dcrd_gasolina_premium'),
'Gasolina Regular'=>get_option('dcrd_gasolina_regular'),
'Gasoil Regular'=>get_option('dcrd_gasoil_regular'),
'Gasoil Óptimo'=>get_option('dcrd_gasoil_optimo'),
'GLP'=>get_option('dcrd_glp'),
'Gas Natural'=>get_option('dcrd_gas_natural'),
];
foreach($combustibles as $n=>$v){ echo "<tr><td>$n</td><td class='valor'>RD$ $v</td></tr>"; }
?>
</table></div>
<?php return ob_get_clean(); }
add_shortcode('divisas_combustibles_rd','dcrd_shortcode');

// WIDGET
class Divisas_Combustibles_RD_Widget extends WP_Widget {
    function __construct(){ parent::__construct('divisas_combustibles_rd_widget','Divisas y Combustibles RD'); }
    function widget($a,$i){ echo $a['before_widget'].do_shortcode('[divisas_combustibles_rd]').$a['after_widget']; }
}
add_action('widgets_init',function(){ register_widget('Divisas_Combustibles_RD_Widget'); });
?>
