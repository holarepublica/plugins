<?php
/**
 * Plugin Name: HR GitHub Updater
 * Description: Actualiza plugins desde GitHub.
 * Version: 1.0
 * Author: HolaRepublica
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Ruta al archivo del updater
require_once plugin_dir_path(__FILE__) . 'includes/hr-github-updater/hr-github-updater.php';

// Inicializar el updater
add_action('plugins_loaded', function () {
    if (class_exists('HR_GitHub_Updater')) {
        new HR_GitHub_Updater(__FILE__, 'holarepublica', 'NOMBRE_DEL_REPOSITORIO');
    }
});
