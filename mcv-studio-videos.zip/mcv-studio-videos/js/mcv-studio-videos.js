document.addEventListener('DOMContentLoaded', function(){
    const playerDiv = document.querySelector('.mcv-video-player');
    if(!playerDiv) return;

    const playlistId = playerDiv.dataset.playlist;
    const apiKey = playerDiv.dataset.api;
    const galleryCount = parseInt(playerDiv.dataset.gallery);
    const mainPlayer = document.getElementById('mcvYTMain');
    const galleryContainer = document.getElementById('mcvYTGallery');

    if(!playlistId || !apiKey) return;

    fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=${galleryCount+1}&playlistId=${playlistId}&key=${apiKey}`)
    .then(response => response.json())
    .then(data => {
        if(!data.items || !data.items.length) return;

        // Video principal
        const mainVideoId = data.items[0].snippet.resourceId.videoId;
        mainPlayer.innerHTML = `<iframe width="100%" height="315" src="https://www.youtube.com/embed/${mainVideoId}?enablejsapi=1" frameborder="0" allowfullscreen></iframe>`;

        // Galería
        galleryContainer.innerHTML = '';
        data.items.slice(1, galleryCount+1).forEach(item => {
            const videoId = item.snippet.resourceId.videoId;
            const thumbnail = item.snippet.thumbnails.medium.url;
            const title = item.snippet.title;

            const thumb = document.createElement('div');
            thumb.classList.add('mcv-thumb');
            thumb.innerHTML = `<img src="${thumbnail}" alt="${title}"><p>${title}</p>`;
            thumb.addEventListener('click', () => {
                mainPlayer.innerHTML = `<iframe width="100%" height="315" src="https://www.youtube.com/embed/${videoId}?enablejsapi=1" frameborder="0" allowfullscreen></iframe>`;
            });

            galleryContainer.appendChild(thumb);
        });
    });
});
