<?php
/**
 * Plugin Name: MCV Studio Videos
 * Description: Reproductor de videos con playlist estilo Jannah, versión 1.2, creado por MCV Studio.
 * Version: 1.2
 * Author: MCV Studio
 */

if (!defined('ABSPATH')) exit;

// ----------------------------
// Enqueue CSS y JS
// ----------------------------
function mcv_studio_videos_enqueue_scripts() {
    wp_enqueue_style('mcv-studio-videos-css', plugin_dir_url(__FILE__) . 'css/mcv-studio-videos.css');
    wp_enqueue_script('mcv-studio-videos-js', plugin_dir_url(__FILE__) . 'js/mcv-studio-videos.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'mcv_studio_videos_enqueue_scripts');

// ----------------------------
// Shortcode: Playlist con galería
// ----------------------------
function mcv_studio_videos_youtube_gallery_shortcode($atts) {
    $atts = shortcode_atts(array(
        'playlist_id' => '',
        'api_key' => '',
        'gallery_count' => 3, // Cantidad de videos debajo
    ), $atts, 'mcv_yt_gallery');

    if(empty($atts['playlist_id']) || empty($atts['api_key'])) {
        return '<p>No se ha configurado el ID de la playlist o la API Key.</p>';
    }

    $playlist_id = esc_attr($atts['playlist_id']);
    $api_key = esc_attr($atts['api_key']);
    $gallery_count = intval($atts['gallery_count']);

    return '
    <div class="mcv-video-player" data-playlist="'.$playlist_id.'" data-api="'.$api_key.'" data-gallery="'.$gallery_count.'">
        <div id="mcvYTMain"></div>
        <div class="mcv-gallery" id="mcvYTGallery"></div>
        <div class="mcv-controls">
            <span class="mcv-credit">MCV Studio</span>
        </div>
    </div>';
}
add_shortcode('mcv_yt_gallery', 'mcv_studio_videos_youtube_gallery_shortcode');

// ----------------------------
// Widget Playlist YouTube
// ----------------------------
class MCV_Studio_YT_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'mcv_studio_yt_widget',
            'MCV Studio YouTube Playlist',
            array('description' => 'Muestra un reproductor de playlist de YouTube con galería y título personalizado')
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        $title = !empty($instance['title']) ? apply_filters('widget_title', $instance['title']) : '';
        $playlist_id = !empty($instance['playlist_id']) ? esc_attr($instance['playlist_id']) : '';
        $api_key = !empty($instance['api_key']) ? esc_attr($instance['api_key']) : '';
        $gallery_count = !empty($instance['gallery_count']) ? intval($instance['gallery_count']) : 3;

        if($title) echo $args['before_title'] . $title . $args['after_title'];
        if($playlist_id && $api_key){
            echo do_shortcode('[mcv_yt_gallery playlist_id="'.$playlist_id.'" api_key="'.$api_key.'" gallery_count="'.$gallery_count.'"]');
        } else {
            echo '<p>Configura el ID de la playlist y la API Key.</p>';
        }
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Playlist MCV Studio';
        $playlist_id = !empty($instance['playlist_id']) ? $instance['playlist_id'] : '';
        $api_key = !empty($instance['api_key']) ? $instance['api_key'] : '';
        $gallery_count = !empty($instance['gallery_count']) ? intval($instance['gallery_count']) : 3;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Título:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
            name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('playlist_id'); ?>">ID de Playlist:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('playlist_id'); ?>"
            name="<?php echo $this->get_field_name('playlist_id'); ?>" type="text" value="<?php echo esc_attr($playlist_id); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('api_key'); ?>">API Key de YouTube:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('api_key'); ?>"
            name="<?php echo $this->get_field_name('api_key'); ?>" type="text" value="<?php echo esc_attr($api_key); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('gallery_count'); ?>">Cantidad de videos en galería:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('gallery_count'); ?>"
            name="<?php echo $this->get_field_name('gallery_count'); ?>" type="number" value="<?php echo esc_attr($gallery_count); ?>" min="1" max="10">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['playlist_id'] = strip_tags($new_instance['playlist_id']);
        $instance['api_key'] = strip_tags($new_instance['api_key']);
        $instance['gallery_count'] = intval($new_instance['gallery_count']);
        return $instance;
    }
}

function register_mcv_studio_yt_widget() {
    register_widget('MCV_Studio_YT_Widget');
}
add_action('widgets_init', 'register_mcv_studio_yt_widget');
