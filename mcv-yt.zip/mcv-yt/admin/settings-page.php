<?php
if (!defined('ABSPATH')) exit;

function mcvyt_register_settings() {
    add_option('mcvyt_github_user', '');
    add_option('mcvyt_github_repo', '');
    add_option('mcvyt_github_token', '');

    register_setting('mcvyt_settings', 'mcvyt_github_user');
    register_setting('mcvyt_settings', 'mcvyt_github_repo');
    register_setting('mcvyt_settings', 'mcvyt_github_token');
}
add_action('admin_init', 'mcvyt_register_settings');

function mcvyt_settings_menu() {
    add_options_page(
        'MCV-YT Configuración',
        'MCV-YT',
        'manage_options',
        'mcv-yt-settings',
        'mcvyt_settings_page'
    );
}
add_action('admin_menu', 'mcvyt_settings_menu');

function mcvyt_settings_page() {
    ?>
    <div class="wrap">
        <h1>Configuración de MCV-YT</h1>
        <form method="post" action="options.php">
            <?php settings_fields('mcvyt_settings'); ?>

            <table class="form-table">
                <tr>
                    <th>Usuario de GitHub</th>
                    <td><input type="text" name="mcvyt_github_user" 
                        value="<?php echo esc_attr(get_option('mcvyt_github_user')); ?>" 
                        size="40"></td>
                </tr>

                <tr>
                    <th>Repositorio</th>
                    <td><input type="text" name="mcvyt_github_repo" 
                        value="<?php echo esc_attr(get_option('mcvyt_github_repo')); ?>" 
                        size="40">
                        <p class="description">Ejemplo: mcv-yt</p>
                    </td>
                </tr>

                <tr>
                    <th>GitHub Token (opcional)</th>
                    <td><input type="text" name="mcvyt_github_token" 
                        value="<?php echo esc_attr(get_option('mcvyt_github_token')); ?>" 
                        size="40">
                        <p class="description">Solo si el repositorio es privado.</p>
                    </td>
                </tr>
            </table>

            <input type="submit" class="button button-primary" value="Guardar cambios">
        </form>
    </div>
    <?php
}
