jQuery(document).ready(function($){

    console.log("MCV-YT cargado correctamente");

});
