<?php
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'shortcode.php';
require_once plugin_dir_path(__FILE__) . 'widget.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'admin/settings-page.php';
