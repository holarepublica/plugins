<?php
if (!defined('ABSPATH')) exit;

// Crear menú
add_action('admin_menu', function() {
    add_options_page(
        'MCV-YT Configuración',
        'MCV-YT',
        'manage_options',
        'mcv-yt-settings',
        'mcvyt_settings_page'
    );
});

// Registrar opciones
add_action('admin_init', function() {
    register_setting('mcvyt_settings', 'mcvyt_playlist_id');
    register_setting('mcvyt_settings', 'mcvyt_api_key');
});

function mcvyt_settings_page() {
    ?>
    <div class="wrap">
        <h1>MCV-YT – Configuración</h1>

        <form method="post" action="options.php">
            <?php settings_fields('mcvyt_settings'); ?>

            <table class="form-table">
                <tr>
                    <th><label>Playlist ID</label></th>
                    <td><input type="text" name="mcvyt_playlist_id" value="<?php echo get_option('mcvyt_playlist_id'); ?>" size="40"></td>
                </tr>

                <tr>
                    <th><label>API Key</label></th>
                    <td><input type="text" name="mcvyt_api_key" value="<?php echo get_option('mcvyt_api_key'); ?>" size="40"></td>
                </tr>
            </table>

            <input type="submit" class="button button-primary" value="Guardar cambios">
        </form>
    </div>
    <?php
}
