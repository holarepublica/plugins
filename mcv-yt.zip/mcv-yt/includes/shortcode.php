<?php
if (!defined('ABSPATH')) exit;

// Shortcode [mcv_yt]
function mcvyt_shortcode() {
    ob_start();

    $playlist = get_option('mcvyt_playlist_id');
    $apikey   = get_option('mcvyt_api_key');

    if (!$playlist || !$apikey) {
        return "<p style='color:red;'>Configura tu Playlist ID y API Key en Ajustes → MCV-YT</p>";
    }

    ?>
    <div class="mcvyt-container">
        <iframe 
            id="mcvyt-player"
            width="100%" 
            height="300"
            src="https://www.youtube.com/embed?listType=playlist&list=<?php echo $playlist; ?>" 
            frameborder="0" 
            allowfullscreen>
        </iframe>

        <div id="mcvyt-gallery">
            Cargando videos...
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode('mcv_yt', 'mcvyt_shortcode');
