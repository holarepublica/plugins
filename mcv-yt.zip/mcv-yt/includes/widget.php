<?php
if (!defined('ABSPATH')) exit;

class MCVYT_Widget extends WP_Widget {

    function __construct() {
        parent::__construct(
            'mcvyt_widget',
            __('MCV-YT Videos', 'mcvyt'),
            array('description' => __('Muestra tu playlist de YouTube', 'mcvyt'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        echo do_shortcode('[mcv_yt]');
        echo $args['after_widget'];
    }
}

add_action('widgets_init', function() {
    register_widget('MCVYT_Widget');
});
