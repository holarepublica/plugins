<?php
/*
Plugin Name: MCV-YT
Plugin URI: https://github.com/holarepublica/plugins/tree/main/mcv-yt
Description: Plugin para mostrar playlists y videos de YouTube con estilo moderno, modo oscuro y widget integrado. Creado por MCV Studio.
Version: 1.0.0
Author: MCV Studio
Author URI: https://youtube.com/@MCVStudio
License: MIT
License URI: https://opensource.org/licenses/MIT

Github Plugin URI: https://github.com/holarepublica/plugins
Github Plugin Name: mcv-yt
Github Branch: main
*/

if (!defined('ABSPATH')) exit;

// Loader
require_once plugin_dir_path(__FILE__) . 'includes/loader.php';

// Registrar scripts y estilos
function mcvyt_enqueue_scripts() {
    wp_enqueue_style('mcvyt-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('mcvyt-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'mcvyt_enqueue_scripts');
