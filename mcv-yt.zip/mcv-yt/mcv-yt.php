<?php
/*
Plugin Name: MCV-YT
Description: Playlist YouTube + Actualizaciones automáticas desde GitHub.
Version: 1.0
Author: MCV Studio
*/

if (!defined('ABSPATH')) exit;

// Cargar página de configuración
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';

// Cargar updater
require_once plugin_dir_path(__FILE__) . 'includes/hr-github-updater/hr-github-updater.php';

// Inicializar updater con datos guardados en WP
add_action('plugins_loaded', function() {

    $config = [
        'slug'              => 'mcv-yt/mcv-yt.php',
        'proper_slug'       => 'mcv-yt',
        'plugin_name'       => 'MCV-YT',
        'github_user'       => get_option('mcvyt_github_user'),
        'github_repo'       => get_option('mcvyt_github_repo'),
        'github_token'      => get_option('mcvyt_github_token'),
        'requires_wp'       => '5.0',
        'tested_wp'         => '6.7',
    ];

    if (!empty($config['github_user']) && !empty($config['github_repo'])) {
        new HR_GitHub_Updater(__FILE__, $config);
    }
});
